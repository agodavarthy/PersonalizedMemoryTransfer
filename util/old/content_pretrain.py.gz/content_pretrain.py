"""
Script extracts all the movies then searches in our DB of plots/titles
then tokenizes it and stores it in a file, then applies some text vectorizer
"""
import os
import numpy as np
import pickle
import pandas as pd
import pymongo
from tqdm import tqdm
import argparse
from util.old.movie_data import TextEncoder, tokenizer, get_key_in_order
import bottleneck
from util.data_handler import ITEM_ID_LIMIT

parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
parser.add_argument('-g', '--gpu', help='set gpu device number 0-3', type=str,
                    default="")


if __name__ == '__main__':
    filename_content_raw = "data/ml_content_raw.pkl"
    filename_content_vec = "data/ml_content.pkl"

    # Load vectorized text if exists
    if os.path.exists(filename_content_vec):
        print("Loading existing content vectorization")
        content_vec = pickle.load(open(filename_content_vec, 'rb'))
    else:
        # Load existing if we have it
        if os.path.exists(filename_content_raw):
            print("Loading existing content info")
            content = pickle.load(open(filename_content_raw, 'rb'))
        else:
            client = pymongo.MongoClient(port=27021)
            db = client.get_database('movies')
            collection = db.get_collection('movies')

            # MovieLens mapping with matrix id from our split RatingsSplit.ipynb
            movielens = pd.read_csv("data/ml_movies.csv",
                                    dtype={'movieId': int, 'imdbId': str, 'tmdbId': str,
                                           "title": str, 'matrix_itemid': int})
            movielens['plot'] = ""
            missing_entry = 0
            imdb_count = 0
            tmdb_count = 0
            plot_short = 0
            missing = []

            for idx, row in tqdm(movielens.iterrows()):
                item = collection.find_one({"_id": int(row['movieId'])})
                if item is None:
                    missing_entry += 1
                    continue

                title = item.get('title', row['title'])
                plot = ""

                if 'imdb' in item and len(item['imdb']):
                    imdb = item['imdb']
                    title = get_key_in_order(imdb, ['smart canonical title', 'canonical title', 'title'], title)
                    plot = get_key_in_order(imdb, ['plot', 'plot outline', 'synopsis', 'summary', 'plot summary'], "")
                    if isinstance(plot, list):
                        best_plot = plot[0]
                        # Assume the longest plot is the best
                        for p in plot[1:]:
                            if len(p) > len(best_plot):
                                best_plot = p
                        plot = best_plot
                # Check if we did not find the plot
                if 'tmdb' in item and len(plot) == 0:
                    title = item['tmdb']['title']
                    plot = item['tmdb']['overview']
                    tmdb_count += 1
                elif len(plot):
                    imdb_count += 1

                if len(plot) == 0:
                    plot_short += 1

                movielens.loc[idx, 'title'] = title
                movielens.loc[idx, 'plot'] = plot

            print(f"""
            IMDB Count:   {imdb_count:,}
            TMDB Count:   {tmdb_count:,}
            No Plot:      {plot_short:,}

            Missing:      {missing_entry}
            """)

            # Join together, title and plot
            movielens['text'] = movielens.title.str.cat(movielens['plot'], sep=" ")
            # Strip
            movielens.text = movielens.text.str.strip()

            # Tokenize
            movielens.text = movielens.text.map(tokenizer)

            content = {_id: text for _id, text in movielens[['matrix_itemid', 'text']].values}

            # Tokenize
            pickle.dump(content, open(filename_content_raw, 'wb'),
                        pickle.HIGHEST_PROTOCOL)

        print("Vectorizing text....")
        opt = parser.parse_args()
        encoder = TextEncoder(opt.gpu)
        content_vec = {_id: encoder.encode(" ".join(text))[0] for _id, text in tqdm(content.items())}

        # Vectorized content version
        pickle.dump(content_vec, open(filename_content_vec, 'wb'),
                    pickle.HIGHEST_PROTOCOL)

    content = np.vstack([content_vec[idx] for idx in range(len(content_vec))])
    # MovieLens has additional items but no feedback
    content = content[:ITEM_ID_LIMIT]
    similarity = content.dot(content.T)
    del content

    top_k = 300
    # Item Indices for most similar and least similar
    pos_index = bottleneck.argpartition(similarity, top_k)[:, :top_k].astype('uint32')
    neg_index = bottleneck.argpartition(-similarity, top_k)[:, :top_k].astype('uint32')

    np.savez_compressed("data/ml_content_sim.npz", **{
        "pos_index": pos_index,
        "neg_index": neg_index,
        "sim": similarity.astype(np.float16)
    })
