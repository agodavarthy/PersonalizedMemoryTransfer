#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@author:   Travis A. Ebesu
@created:  2017-05-08
@summary:  Helper functions for GraphKeys, Optimizer Arguments,
           creating experiment directories and configurations.
"""
import argparse
import json
import logging
import sys
import shutil
import os
import pickle
from itertools import chain
from logging.config import dictConfig
import time
import datetime as dt
import math

import tensorflow as tf

import torch
import torch.nn.init
from rutil.util import parser_add_str2bool


def caffe_init(tensor: torch.Tensor):
    """
    Initialization is done in place, inits to Uniform(sqrt(1/fan_in))
    Convolutional Architecture for Fast Feature Embedding
        factor=1.0 mode='FAN_IN' uniform=True

    :param tensor:
    """
    fan_in, fan_out = torch.nn.init._calculate_fan_in_and_fan_out(tensor)
    init = math.sqrt(1.0 / fan_in)
    with torch.no_grad():
        tensor.uniform_(-init, init)


# def init_tensor(tensor: torch.Tensor, init_type: str):
#     """
#     He init
#     To get Delving Deep into Rectifiers (also know as the "MSRA initialization"), use (Default):
#         factor=2.0 mode='FAN_IN' uniform=False
#
#     To get Convolutional Architecture for Fast Feature Embedding, use:
#         factor=1.0 mode='FAN_IN' uniform=True
#
#     To get Understanding the difficulty of training deep feedforward neural networks, use:
#         factor=1.0 mode='FAN_AVG' uniform=True.
#
#     To get xavier_initializer use either:
#         factor=1.0 mode='FAN_AVG' uniform=True, or
#         factor=1.0 mode='FAN_AVG' uniform=False.
#
#
#     :param tensor:
#     :param init_type: Init type: xavier, xavier_uni, he, he_norm, caffe,
#                       caffe_norm
#     :return:
#     """
#     fan_in, fan_out = torch.nn.init._calculate_fan_in_and_fan_out
#
#     if init_type in {"xavier", "xavier_uni"}:
#         n = (fan_in + fan_out) / 2.0
#         factor = 1.0
#     elif init_type in {"he", "he_norm"}:
#         n = fan_in
#         factor = 2.0
#     elif init_type in {"caffe", "caffe_norm"}:
#         n = fan_in
#         factor = 1.0
#     else:
#         raise Exception("Unknown initialization type")
#     init = math.sqrt(1.0 / fan_in)
#     with torch.no_grad():
#         tensor.uniform_(-init, init)
    # math.sqrt(factor / n)
    # if init_type.endswith("_norm"):
    #     std = math.sqrt(2.0 / (fan_in + fan_out))
    #     with torch.no_grad():
    #         return tensor.normal_(0, std)
    # else:
    #
    # return {
    #     'xavier': variance_scaling_initializer(factor=1.0, mode='FAN_AVG',
    #                                            uniform=False),
    #     'xavier_uni': variance_scaling_initializer(factor=1.0, mode='FAN_AVG',
    #                                                uniform=False),
    #     'he': variance_scaling_initializer(factor=2.0, mode='FAN_IN',
    #                                        uniform=False),
    #     'he_norm': variance_scaling_initializer(factor=2.0, mode='FAN_IN',
    #                                             uniform=True),
    #
    #     'caffe': variance_scaling_initializer(factor=1.0, mode='FAN_IN',
    #                                           uniform=True),
    #     'caffe_norm': variance_scaling_initializer(factor=1.0, mode='FAN_IN',
    #                                                uniform=False)
    # }[init_type]


def setup_exp(opt):
    """
    Creates directories, copies main file to it and saves the configuration
    :param opt: Output from parser.parse_args()
    """
    if not hasattr(opt, 'model_file'):
        print("[Options Passed has no attribute model_file]")
        return

    if opt.model_file is None:
        return

    # creating output folders
    os.makedirs(opt.model_file, exist_ok=True)

    # Copy file to result directory for reproducability
    full_path = os.path.realpath(sys.argv[0])
    # _fname = os.path.basename(sys.argv[0])
    # directory = os.path.join(os.path.dirname(os.path.realpath(__file__)),
    #                          _fname)
    backup_path = os.path.join(opt.model_file, os.path.basename(full_path))

    if not os.path.exists(backup_path):
        print(f"Copying {full_path} ==> {backup_path}")
        shutil.copy2(full_path, backup_path)
        json.dump(opt.__dict__, open(os.path.join(opt.model_file, "config.json"), 'w'))


def copy_files(model_directory, copy_dirs=None):
    """
    Copies the current file and all copy_dirs to the model_directory preserving
    the directory structure of the copy_dirs.

    :param model_directory: Path to where to copy the files, it will create it
                            recursively if directory does not exist.
    :param copy_dirs: list of directories to copy
    :return:
    """
    main_file = os.path.join(os.path.dirname(os.path.realpath(__file__)),
                             os.path.basename(sys.argv[0]))
    if not os.path.exists(model_directory):
        os.makedirs(model_directory)
    shutil.copy2(main_file, os.path.join(model_directory, main_file))

    if copy_dirs is not None:
        for d in copy_dirs:
            shutil.copytree(d, model_directory + "/" + d,
                            ignore=shutil.ignore_patterns('*.pyc', '.*', '#*',
                                                          '*.mtx', '*.pkl'))


class BaseConfig(object):
    """
    Base Config to handle saving/loading.

    TODO: Refactor out this adds unnecessary complexity
    """
    save_directory = None
    _IGNORE = ['fields', 'save', 'load']

    # Set Custom Parameters by name with init
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)

    @property
    def fields(self):
        """
        Get all fields/properties stored in this config class
        """
        return [m for m in dir(self)
                if not m.startswith('_') and m not in self._IGNORE]

    def save(self):
        """
        Config is dumped as a json file and pickle
        """
        json.dump(self._get_dict(),
                  open('%s/config.json' % self.save_directory, 'w'),
                  sort_keys=True, indent=2)
        pickle.dump({key: self.__getattribute__(key) for key in self.fields},
                    open('%s/config.pkl' % self.save_directory, 'wb'),
                    pickle.HIGHEST_PROTOCOL)

    def load(self):
        """
        Load config, equivalent to loading json and updating this classes' dict
        Tries to load picle first then falls back to json
        """
        try:
            d = pickle.load(open('%s/config.pkl' % self.save_directory))
            self.__dict__.update(d)
        except Exception:
            d = json.load(open('%s/config.json' % self.save_directory))
            self.__dict__.update(d)

    def _get_dict(self):
        return {key: self.__getattribute__(key) if isinstance(self.__getattribute__(key), (int, float))
                else str(self.__getattribute__(key)) for key in self.fields}

    def __repr__(self):
        return json.dumps(self._get_dict(), sort_keys=True, indent=2)

    def __str__(self):
        return json.dumps(self._get_dict(), sort_keys=True, indent=2)


class GraphKeys(object):
    """
    Custom GraphKeys; primarily to be backwards compatable incase tensorflow
    changes it. Also to add my own names

    https://github.com/tensorflow/tensorflow/blob/r1.1/tensorflow/python/framework/ops.py#L3921
    """
    TRAINABLE_VARIABLES = "trainable_variables"
    PLACEHOLDER = 'placeholder'
    PREDICTION = 'prediction'
    ATTTENTION = 'attention'
    TRAIN_OP = 'train_op'
    EVAL_STEP = 'eval_step'
    LOSSES = 'losses'
    WEIGHTS = 'weights'
    BIASES = 'biases'
    REG_WEIGHTS = 'reg_weights'
    USER_WEIGHTS = 'user_weights'
    ITEM_WEIGHTS = 'item_weights'
    GRADIENTS = 'gradients'

    # Regularization l1/l2 Penalty that would be added
    LOSS_REG = 'regularization_losses'

    # Loss Value without Penalty
    LOSS_NO_REG = 'loss'

    # Keys for the activation of a layer
    ACTIVATIONS = 'activations'

    # Keys for prior to applying the activation function of a layer
    PRE_ACTIVATIONS = 'pre_activations'

    SUMMARIES = 'summaries'
    METRIC_UPDATE = 'metric_update'
    METRIC = 'metric'
    TRAIN = 'train_op'


# List of optimizer classes mappings
OPTIMIZER = {
    # learning_rate=0.001, beta1=0.9, beta2=0.999
    'adam': tf.train.AdamOptimizer,

    # Lazy Adam only updates momentum estimators on values used; it may cause
    # different results than adam
    'lazyadam': tf.contrib.opt.LazyAdamOptimizer,

    # learning_rate, initial_accumulator_value=0.1
    'adagrad': tf.train.AdagradOptimizer,

    # learning_rate, decay=0.9, momentum=0.0
    'rmsprop': tf.train.RMSPropOptimizer,

    # learning_rate, momentum,  use_nesterov=False
    'momentum': tf.train.MomentumOptimizer,

    # learning_rate=0.001, rho=0.95, epsilon=1e-08
    'adadelta': tf.train.AdadeltaOptimizer,

    'sgd': tf.train.GradientDescentOptimizer,
}

# Hyperparameters for various optimizers
# learning_rate is for all
_optimizer_args = {
    'adam': ['beta1', 'beta2', 'epsilon'],
    'lazyadam': ['beta1', 'beta2', 'epsilon'],
    'momentum': ['momentum', 'use_nesterov'],
    'rmsprop': ['momentum', 'decay'],
    'adadelta': ['rho']
}


def get_optimizer_argparse():
    """
    Get arguments for our blocks optimizer
    """
    parser = argparse.ArgumentParser(add_help=False)

    optimizer_group = parser.add_argument_group('OPTIMIZATION',
                                                description='Hyperparameters')

    optimizer_group.add_argument('--optimizer', default='adam', help='SGD optimizer',
                                 choices=OPTIMIZER.keys())

    optimizer_group.add_argument('--learning_rate', default=0.001, type=float,
                                 help='learning rate [All]')

    optimizer_group.add_argument('--momentum', default=0.9, type=float,
                                 help='Momentum value [Momentum/RMSProp]')

    optimizer_group.add_argument('--use_nesterov', default=False, action='store_true',
                                 help='Use nesterov momentum [Momentum]')

    optimizer_group.add_argument('--beta1', default=0.9, type=float,
                                 help='beta 1 hyperparameter [Adam]')

    optimizer_group.add_argument('--beta2', default=0.999, type=float,
                                 help='beta 1 hyperparameter [Adam]')

    optimizer_group.add_argument('--epsilon', default=1e-08, type=float,
                                 help='Epsilon for numerical stability [Adam]')

    optimizer_group.add_argument('--decay', default=0.9, type=float,
                                 help='decay rate hyperparameter [RMSProp]')

    optimizer_group.add_argument('--rho', default=0.95, type=float,
                                 help='rho hyperparameter [Adadelta]')
    return parser


def _preprocess_args(parsed_obj, remove_attrs, keep_attrs, keyname):
    """
    Note modifies inplace. Removes the attributes from a given class object and
    consolidates list of keep_attrs to a single dictionary and sets the
    attribute in the object with keyname.

    :param parsed_obj: object to access via attributes
    :param remove_attrs: iterable of keys of attributes to remove
    :param keep_attrs: iterable of keys to add to a dict and add keyname in
                       namespace
    :param keyname: str, name of key to add keep_attrs to as a dict
    """
    args = {attr: getattr(parsed_obj, attr) for attr in keep_attrs}
    setattr(parsed_obj, keyname, args)

    for attr in remove_attrs:
        delattr(parsed_obj, attr)


def preprocess_args(FLAGS):
    """Preprocess valid arguments and sets defaults for optimizers"""
    _preprocess_args(FLAGS, set(list(chain.from_iterable(_optimizer_args.values()))),
                     _optimizer_args[FLAGS.optimizer], 'optimizer_params')


def add_to_collection(names, values):
    """
    Adds multiple elements to a given collection(s)

    :param names: str or list of collections
    :param values: tensor or list of tensors to add to collection
    """
    if isinstance(names, str):
        names = [names]
    if isinstance(values, str):
        values = [values]
    for name in names:
        for value in values:
            tf.add_to_collection(name, value)


def create_exp_directory(cwd: str=''):
    """
    Creates a new directory to store experiment to save data. It will try to
    create a new folder name sequentially from 1 to 10000, if all of them exist
    it throws an error.

    :param cwd: Current working directory to create a new experiment in
    :return: The newly created experiment directory
    """
    created = False
    for i in range(1, 10000):
        exp_dir = str(i).zfill(3)
        path = os.path.join(cwd, exp_dir)
        if not os.path.exists(path):
            # Create directory
            os.mkdir(path)
            created = True
            break
    if not created:
        raise Exception('Could not create directory for experiments')
    return path + '/'


def set_logging_config(save_directory: str):
    """
    Get a logging dictionary configuration which will also add a filehandler to
    the save_directory

    :param save_directory:
    :return: dict
    """
    # Setup Logging
    dictConfig(dict(
        version=1,
        formatters={
            # For files
            'detailed': {
                'format': "[%(asctime)s - %(levelname)s:%(name)s]<%(funcName)s>:%(lineno)d: %(message)s",
            },
            # For the console
            'console': {
                'format':"[%(levelname)s:%(name)s]<%(funcName)s>:%(lineno)d: %(message)s",
            }
        },
        handlers={
            'console': {
                'class': 'logging.StreamHandler',
                'level': logging.INFO,
                'formatter': 'console',
            },
            'file': {
                'class': 'logging.handlers.RotatingFileHandler',
                'level': logging.DEBUG,
                'formatter': 'detailed',
                'filename': "{}/log".format(save_directory),
                'mode': 'a',
                'maxBytes': 10485760,  # 10 MB
                'backupCount': 5
            }
        },
        loggers={
            'tensorflow': {
                'level': logging.INFO,
                'handlers': ['console', 'file'],
            }
        },
        disable_existing_loggers=False,
    ))


class Timer(object):
    """
    Computes elapsed time.
    https://github.com/facebookresearch/ParlAI/blob/52493d792d9f361c2711ca1340a5ed3b4d372456/parlai/core/utils.py#L172
    """
    def __init__(self):
        self.running = True
        self._total = 0
        self._start = time.time()

    def reset(self):
        """Reset the time"""
        self.running = True
        self._total = 0
        self._start = time.time()
        return self

    def resume(self):
        """Resume if we stopped"""
        if not self.running:
            self.running = True
            self._start = time.time()
        return self

    def stop(self):
        """Stop timer"""
        if self.running:
            self.running = False
            self._total += time.time() - self._start
        return self

    def time(self):
        """Return the number of seconds since started"""
        if self.running:
            return self._total + time.time() - self._start
        return self._total

    def eta(self, current, total):
        """
        Return a ETA given the progress
        :param current: Current number of count
        :param total: Number of total size
        :return: string
        """
        if current > 0:
            eta = self.time() / current * (total-current)
            return str(dt.timedelta(seconds=eta)).split(".")[0]
        else:
            return "???"

    def __str__(self):
        return str(dt.timedelta(seconds=self.time())).split(".")[0]

    def __repr__(self):
        return str(dt.timedelta(seconds=self.time())).split(".")[0]


class ProgressBar(object):
    def __init__(self, fill='=', empty=' ', tip='>', begin='[', end=']',
                 precision=1, clear=True):
        """

        Adapted from Eric Wu

        fill        - Optional : bar fill character                         [str] (ex: 'â– ', 'â–ˆ', '#', '=')
        empty       - Optional : not filled bar character                   [str] (ex: '-', ' ', 'â€¢')
        tip         - Optional : character at the end of the fill bar       [str] (ex: '>', '')
        begin       - Optional : starting bar character                     [str] (ex: '|', 'â–•', '[')
        end         - Optional : ending bar character                       [str] (ex: '|', 'â–', ']')
        clear       - Optional : display completion message or leave as is  [str]

        :param fill:
        :param empty:
        :param tip:
        :param begin:
        :param end:
        :param precision: precision for showing percentage
        :param clear:
        """
        self.fill = fill
        self.empty = empty
        self.tip = tip
        self.begin = begin
        self.end = end
        self.clear = clear
        self.precision = precision
        self.timer = Timer()
        self.lifetime = Timer()

    def print(self, step: int, total_steps: int, prefix: str='', suffix: str='',
              done: str="[DONE]", length: int=100):
        """
        Print iterations progress.
        Call in a loop to create terminal progress bar

        [Prefix String][Begin Marker][Progress][End Marker]
        [Percent Done] % [Lifetime Total Time] (eta [Estimated Time for Epoch])
        [Suffix String]


        :param step: Current step for progress
        :param total_steps: Total number of steps
        :param prefix: Prefix string to show
        :param suffix: Suffix string to show
        :param done: (Optional) display message when 100% is reached
        :param length: (Optional) character length of bar
        """
        # percent = ("{0:." + str(self.decimals) + "f}").format(100 * (step / float(total_steps)))
        percent = "{0:.{precision}f}".format(100 * (step / float(total_steps)),
                                             precision=self.precision)
        percent = "{}% {} (eta {})".format(percent, self.timer, self.timer.eta(step, total_steps))

        filled_length = int(length * step // total_steps)
        bar = self.fill * filled_length
        if step != total_steps:
            bar = bar + self.tip
        bar = bar + self.empty * (length - filled_length - len(self.tip))
        display = '\r{prefix}{begin}{bar}{end} {percent}{suffix} ' \
            .format(prefix=prefix, begin=self.begin, bar=bar, end=self.end,
                    percent=percent, suffix=suffix)
        print(display, end=''),  # comma after print() required for python 2
        if step == total_steps:  # print with newline on complete
            # display given complete message with spaces to 'erase' previous progress bar
            finish = '\r{prefix}{done}'.format(prefix=prefix, done=done)
            # Pad the right with spaces
            print(finish.ljust(max(len(display) - len(finish), 0)))

            if self.clear:
                # print("".ljust(256))
                print('')

            # Reset epoch timer
            self.timer.reset()


if __name__ == '__main__':
    CEND = '\33[0m'
    # black letters on white background use ESC[30;47m
    CSI = "\x1B["
    #Should we use: \33 or \x1B ?
    # 31 = Font FontColor
    # 40 = ;40
    print(CSI + "31m" + "Colored Text" + CSI + "0m")
    print(CSI + "92m" + "Colored Text" + CSI + "0m")
    print(CSI + "32m" + "Colored Text" + CSI + "0m")

    pbar = ProgressBar()
    print()
    # pbar.print(5, 10)
    for i in range(10):
        time.sleep(0.25)
        pbar.print(i, 9)
    print()


def get_parser():
    """
    Get argparser

    :return:
    """
    parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser_add_str2bool(parser)
    parser.add_argument('-g', '--gpu', help='set gpu device number 0-3', type=int,
                        default=0)
    parser.add_argument('-d', '--data', help='MoviesData Input', type=str,
                        required=True)
    parser.add_argument('-mf', '--model_file', help='path to model.pth', type=str,
                        required=True)
    parser.add_argument('-wc', '--weighted_count', help='Number of top item latent factors to consider', type=int,
                        default=300)
    parser.add_argument('-n', '--neg_count', help='Number of negatives to sample', type=int,
                        default=10)
    parser.add_argument('-lr', '--lr', help='Learning Rate', type=float,
                        default=0.1)
    parser.add_argument('-mom', '--momentum', help='Learning Rate', type=float,
                        default=0.9)
    parser.add_argument('-m', '--model', help='path to model directory',
                        type=str, default='gmf', choices=['gmf', 'mf'])
    parser.add_argument('-s', '--sampling', help='path to model directory',
                        type=str, default='random', choices=['hard', 'random'])
    parser.add_argument('-save', '--save', help='Save results to the conv file?'
                                                ' Does not apply to multi_exp.py',
                        type='bool', default=True)
    parser.add_argument('-overwrite', '--overwrite', help='overwrite the saved entry',
                        type='bool', default=False)
    parser.add_argument('-seed', '--seed', help='Random seed, used to create '
                                                'additional bootstrap samples',
                        type=int, default=42)
    parser.add_argument('-norm', '--norm', help='path to model directory',
                        type=str, default='softmax', choices=['softmax', 'l2'])
    parser.add_argument('-update', '--update', help='When to update the model? after seeker speaks or after every turn',
                        type=str, default='seeker', choices=['seeker', 'all', 'rec'])
    parser.add_argument('-v', '--verbose', help='Print out each conversation results',
                        type='bool', default=False)
    parser.add_argument('-replay', '--replay', help='Use replay buffer?',
                        type='bool', default=False)
    return parser