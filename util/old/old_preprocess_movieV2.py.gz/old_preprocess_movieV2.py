"""
Script extracts all the movies then searches in our DB of plots/titles
then tokenizes it and stores it in a file, then applies some text vectorizer
"""
import os
import numpy as np
import pickle
import pandas as pd
import pymongo
from tqdm import tqdm
import argparse
# sys.path.append("../")
import util.data
import util.data_handler
from util.old.movie_data import tokenizer, get_key_in_order

parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
parser.add_argument('-d', '--data_split', help='Directory to datasplit, should have movie_map.csv', type=str,
                    required=True)


def create_pickle_format(movies_df, content_vec_dict, filename_output):
    movie_list = []
    for _, row in movies_df.iterrows():
        movie_list.append(util.data.Movie(movie_id=row['movie_id'],
                                          ml_id=row['ml_id'],
                                          matrix_id=row['matrix_id'],
                                          title=row['title'],
                                          plot=row['plot'],
                                          tmdb_id=row['tmdbId'],
                                          imdb_id=row['imdbId'],
                                          plot_tokens=tokenizer(row['plot']),
                                          title_tokens=tokenizer(row['title']),
                                          vector=content_vec_dict[row['ml_id']]).to_dict())
    print(f"Writing to {filename_output}")
    # Movie Meta Data
    pickle.dump(movie_list,
                open(filename_output, 'wb'),
                pickle.HIGHEST_PROTOCOL)


def create_movie_matrix(movies_df, content_vec, output_filename):
    """
    Create the ordered movie content matrix according to matrix ids
    :param movies_df:
    :param content_vec:
    :param output_filename:
    :return:
    """
    # Create the sorted movie matrix
    movie_matrix = np.vstack([content_vec[row['ml_id']] for _, row in
                              movies_df[movies_df['matrix_id'] >= 0].sort_values('matrix_id').iterrows()])
    np.save(output_filename, movie_matrix)


def create_meta_data(movie_map_path, filename_content_raw):
    """
    Extracts plot info from mongodb

    :param movie_map_path:
    :param filename_content_raw: Filename to write out the csv file
    :return:
    """
    client = pymongo.MongoClient(port=27021)
    db = client.get_database('movies')
    collection = db.get_collection('movies')
    # Reads in this movie map csv
    # MovieLens mapping with matrix id from our datasplit.ipynb
    movies = pd.read_csv(movie_map_path,
                         dtype={'movie_id': int, 'ml_id': int, 'imdbId': str, 'tmdbId': str,
                                "title": str})
    movies['plot'] = ""
    missing_entry = 0
    imdb_count = 0
    tmdb_count = 0
    plot_short = 0
    missing = []

    for idx, row in tqdm(movies.iterrows()):
        item = collection.find_one({"_id": int(row['ml_id'])})
        if item is None:
            missing_entry += 1
            continue

        title = item.get('title', row['title'])
        plot = ""

        if 'imdb' in item and len(item['imdb']):
            imdb = item['imdb']
            title = get_key_in_order(imdb, ['smart canonical title', 'canonical title', 'title'], title)
            plot = get_key_in_order(imdb, ['plot', 'plot outline', 'synopsis', 'summary', 'plot summary'], "")
            if isinstance(plot, list):
                best_plot = plot[0]
                # Assume the longest plot is the best
                for p in plot[1:]:
                    if len(p) > len(best_plot):
                        best_plot = p
                plot = best_plot
        # Check if we did not find the plot
        if 'tmdb' in item and len(plot) == 0:
            title = item['tmdb']['title']
            plot = item['tmdb']['overview']
            tmdb_count += 1
        elif len(plot):
            imdb_count += 1

        if len(plot) == 0:
            plot_short += 1

        movies.loc[idx, 'title'] = title
        movies.loc[idx, 'plot'] = plot

    print(f"""
        IMDB Count:   {imdb_count:,}
        TMDB Count:   {tmdb_count:,}
        No Plot:      {plot_short:,}

        Missing:      {missing_entry}
        """)

    # Join together, title and plot
    movies['text'] = movies.title.str.cat(movies['plot'], sep=" . ")

    # Strip
    movies.text = movies.text.str.strip()

    # Tokenize
    movies.text = movies.text.map(tokenizer)

    movies.text = movies.text.str.join(" ")
    # Remove matrix id because its not actually used for this
    movies.drop(['matrix_id'], axis=1, inplace=True)
    movies.to_csv(filename_content_raw, index=False)


if __name__ == '__main__':
    """
    Create movie meta data
    
    Creates the text from a mapping file and database
    
    Creates:
    data/meta/movie_content.csv, given the movie_map.csv
    
    
    Given the split specific {datasplit_dir}/movie_map.csv created from datasplit.ipynb 
    Creates: {datasplit_dir}/movies_list.pkl
    """
    opt = parser.parse_args()
    meta_base_dir = "data/meta/"
    datasplit_dir = opt.data_split

    # Retrieve these metadata files
    # filename_encoded_content = f"{meta_base_dir}/movie_vec.pkl"
    filename_content_raw = f"{meta_base_dir}/movie_content.csv"
    if not os.path.exists(filename_content_raw):
        # Generic movie_map this one does not use the matrix_id
        print("Creating movie metadata! takes a while...")
        create_meta_data(f"{meta_base_dir}/movie_map.csv", filename_content_raw)

    print("Loading metadata....")
    # these require the appropriate movie_maps
    # filename_content_matrix = f"{datasplit_dir}/movie_matrix"
    output_movies_list = f"{datasplit_dir}/movies_list.pkl"

    # Create the correct matrix ids incase they changed
    movies_df = pd.read_csv(filename_content_raw)
    mapping_df = pd.read_csv(f"{datasplit_dir}/movie_map.csv")
    matrix_map = {ml_id: matrix_id for ml_id, matrix_id in mapping_df[['ml_id', 'matrix_id']].values}
    movies_df['matrix_id'] = movies_df['ml_id'].apply(lambda x: matrix_map[x])

    movie_list = []
    for _, row in movies_df.iterrows():
        movie_list.append(util.data.Movie(movie_id=row['movie_id'],
                                          ml_id=row['ml_id'],
                                          matrix_id=row['matrix_id'],
                                          title=row['title'],
                                          plot=row['plot'],
                                          tmdb_id=row['tmdbId'],
                                          imdb_id=row['imdbId'],
                                          plot_tokens=tokenizer(row['plot']),
                                          title_tokens=tokenizer(row['title'])).to_dict())
    print(f"Writing to {output_movies_list}")
    # Movie Meta Data
    pickle.dump(movie_list,
                open(output_movies_list, 'wb'),
                pickle.HIGHEST_PROTOCOL)

    """    
    print("Vectorizing Movies....")
    encoder = TextEncoder(opt.gpu)
    # Dictionary version keyed with movielens id
    content_vec = {row['ml_id']: encoder.encode(" ".join(tokenizer(row['text'])))[0]
                   for idx, row in tqdm(movies_df.iterrows())}
    # pickle.dump(content_vec, open(filename_encoded_content, 'wb'),
    #             pickle.HIGHEST_PROTOCOL)
    
    # Create the movie similarity matrix
    # print(f"Creating movie similarity matrix in {filename_content_matrix}")
    # create_movie_matrix(movies_df, content_vec, filename_content_matrix)
    # Create in pickle format of movie metadata with correct matrix_ids
    print(f"Creating pickled format in {output_movies_list}")
    create_pickle_format(movies_df, content_vec, output_movies_list)
    """