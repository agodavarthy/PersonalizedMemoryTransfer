"""
Script extracts all the movie mentions then searches in our DB of plots/titles
then tokenizes it and stores it in a file
"""
import numpy as np
from spacy.lang.en import English
import nltk
from symspellpy.symspellpy import SymSpell, Verbosity  # import the module
import symspellpy
import spacy
import os
os.environ['TFHUB_CACHE_DIR'] = os.path.expanduser('~') + "/.cache/tensorflow/"
import tensorflow_hub as hub
import tensorflow as tf

from pytorch_pretrained_bert.tokenization import BertTokenizer
from pytorch_pretrained_bert.modeling import BertModel
# import argparse
# parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
# parser.add_argument('-g', '--gpu', help='set gpu device number 0-3', type=str,
#                     default="")
import torch
import logging
logger = logging.getLogger('tensorflow')
logger.setLevel(logging.CRITICAL)

stopwords = set(nltk.corpus.stopwords.words('english'))

_english = None
_tokenizer_fn = English()
_corrector = None

# _english.from_disk(os.path.join(os.path.dirname(spacy.__file__), "data/en_core_web_lg/en_core_web_lg-2.0.0"))
# from spacy.vocab import Vocab
# vocab = Vocab().from_disk(os.path.join(os.path.dirname(spacy.__file__), "data/en_core_web_lg/en_core_web_lg-2.0.0/vocab"))
# spacy.load("en")

class SpellCorrector(object):

    def __init__(self):
        global _english
        if _english is None:
            print("Loading spacy...")
            _english = spacy.load("en", disable=['parser', 'tagger', 'ner'])
        self._english = _english
        # create object
        initial_capacity = 83000
        # maximum edit distance per dictionary precalculation
        max_edit_distance_dictionary = 2
        prefix_length = 7
        self.sym_spell = SymSpell(initial_capacity, max_edit_distance_dictionary,
                             prefix_length)
        # load dictionary
        dictionary_path = os.path.join(os.path.dirname(symspellpy.__file__),
                                       "frequency_dictionary_en_82_765.txt")
        term_index = 0  # column of the term in the dictionary text file
        count_index = 1  # column of the term frequency in the dictionary text file
        if not self.sym_spell.load_dictionary(dictionary_path, term_index, count_index):
            raise FileNotFoundError("Could not find dictionary to load")

    def correct(self, token, max_edit_dist=2):
        """
        Try to correct the spelling else return the original token

        :param token: str, token
        :param max_edit_dist: int, maximum distance from string
        :return: corrected spacy.Token or original
        """
        # Token should be alpha num but not only numerical
        if token.isalnum() and not token.isnumeric():
            if token not in self._english.vocab:
                sug = self.sym_spell.lookup(token, Verbosity.TOP, max_edit_dist)
                if len(sug):
                    corrected = sug[0].term

                    # Restore title case
                    if token[0].isupper():
                        corrected = corrected[0].upper() + corrected[1:]
                    if corrected in self._english.vocab and token not in self._english.vocab:
                        token = corrected
        return self._english(token)[0]


def get_wordvectors(vocab: set):
    """
    Load the word vectors for a given vocabulary

    :param vocab: set of tokens
    :return: dict of token to vector
    """
    word_vectors = {}

    with open("/home/tebesu/ParlAI/data/models/glove_vectors/glove.6B.50d.txt") as f:
        for line in f:
            line = line.strip().split(' ')
            token = line[0].strip()
            if token in vocab:
                word_vectors[token] = np.asarray(line[1:], np.float32)
    return word_vectors


def tokenizer(text):
    # IMDB summaries sometimes have this at the end to give credits to the
    # summary writer
    idx = text.find(".::")
    if idx != -1:
        text = text[:idx]
    text = text.strip()
    return [token.text for token in _tokenizer_fn(text)]
    # return [token.lemma_ for token in _tokenizer_fn(text)]


def get_key_in_order(item, keys, default=None):
    """Return the first key if present in keys else return
    default, if default is None raises exception"""
    for key in keys:
        if key in item:
            return item[key]
    if default is None:
        raise Exception("Could not find any keys: ", keys)
    return default


class TextEncoder(object):

    def __init__(self, visible_devices: str, encoder: str='uni_transformer'):
        """
        Internally we use a universal sentence encoder
        """
        self._is_bert = encoder == 'bert'
        if self._is_bert:
            torch.cuda.set_device(int(visible_devices))
            # bert-base-uncased, bert-large-uncased, bert-base-cased, bert-large-cased
            # https://github.com/huggingface/pytorch-pretrained-BERT/blob/1cc1c3c34410258fd5bd27ea8163708efc1d2695/README.md#loading-google-ai-or-openai-pre-trained-weights-or-pytorch-dump
            bert_name = 'bert-large-cased'
            self.tokenizer = BertTokenizer.from_pretrained(bert_name, do_lower_case=False)
            # Load pre-trained model (weights)
            self.model = BertModel.from_pretrained(bert_name).eval().cuda()
        else:
            os.environ['CUDA_VISIBLE_DEVICES'] = str(visible_devices)
            os.environ['TFHUB_CACHE_DIR'] = os.path.expanduser('~') + "/.cache/tensorflow/"
            # self._is_elmo = encoder == 'elmo'
            # Initialize Text Encoder
            models = {
                'elmo': "https://tfhub.dev/google/elmo/2",
                # Transformer universal sentence encoder
                "transformer": "https://tfhub.dev/google/universal-sentence-encoder-large/3",
                # Deep averaging network universal sentence encoder
                "dan": "https://tfhub.dev/google/universal-sentence-encoder/2",
                # Simple RNN Language Model
                'nnlm': "https://tfhub.dev/google/nnlm-en-dim128/1",

                # Bert Small
                #'bert': "https://tfhub.dev/google/bert_uncased_L-12_H-768_A-12/1",

                # Bert large
                # 'bert': "https://tfhub.dev/google/bert_uncased_L-24_H-1024_A-16/1",
            }
            self._embed_module = hub.Module(models[encoder])
            self._input_text = tf.placeholder(tf.string, shape=(None))
            self._encoded_text_op = self._embed_module(self._input_text)
            self.sess = tf.Session(
                    config=tf.ConfigProto(gpu_options=tf.GPUOptions(allow_growth=True)))
            self.sess.run([tf.global_variables_initializer(),
                           tf.tables_initializer()])

    def _encode_bert(self, text: str):
        """
        Use bert Pytorch version

        TF version is messy

        :param text:
        :return:
        """
        # text = "[CLS] Who was Jim Henson ? [SEP] Jim Henson was a puppeteer [SEP]"
        # text = "[CLS] " + text.replace(" . ", " [SEP] ").strip()
        # # Add final EOS if required
        # if not text.endswith(" [SEP]"):
        #     text += " [SEP]"
        tokenized_text = self.tokenizer.tokenize("[CLS] " + text + " [SEP]")
        # Convert token to vocabulary indices
        indexed_tokens = self.tokenizer.convert_tokens_to_ids(tokenized_text)[:512]
        segments_ids = [0] * len(indexed_tokens)

        # Convert inputs to PyTorch tensors
        tokens_tensor = torch.tensor([indexed_tokens]).long().cuda()
        segments_tensors = torch.tensor([segments_ids]).long().cuda()

        # Predict hidden states features for each layer
        with torch.no_grad():
            _, pooled_outputs = self.model(tokens_tensor, segments_tensors)

        return pooled_outputs.data.cpu().numpy()

    def encode(self, text):
        """

        :param text: String of text or List of strings
        :return: Encoded Vector from text
        """
        if self._is_bert:
            return self._encode_bert(text)

        if isinstance(text, str):
            text = [text]
        return self.sess.run(self._encoded_text_op, {self._input_text: text})

