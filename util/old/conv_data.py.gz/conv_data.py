import pickle
from util.old.movie_data import tokenizer, TextEncoder
from tqdm import tqdm
from collections import deque
import regex
import pandas as pd
import json
from typing import List
from util.data import Movie
import numpy as np
import argparse
import rutil.util

parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
rutil.util.parser_add_str2bool(parser)
parser.add_argument('-g', '--gpu', help='set gpu device number 0-3', type=str,
                    default="")
parser.add_argument('-o', '--output', help='output filename', type=str,
                    required=True)
parser.add_argument('-i', '--input', help='movies_list.pkl path', type=str,
                    required=True)
parser.add_argument('-m', '--max_examples', help='Max number of examples to '
                                                 'store in pickle file, eg for '
                                                 'validation set (-1 disables)',
                    type=int, default=-1)
parser.add_argument('-hl', '--history_length', help='Number of exchanges in the '
                                                    'conversation to keep for '
                                                    'text encoder',
                    type=int, default=2)
parser.add_argument('-test', '--test', help='Use testing dataset', type='bool',
                    default=False)
parser.add_argument('-seed', '--seed', help='Random seed, used to create '
                                            'additional bootstrap samples',
                    type=int, default=42)
parser.add_argument('-enc', '--encoder', help='Type of text encoder to use',
                    type=str, required=True,
                    choices=['transformer', 'elmo', 'dan', 'nnlm', 'bert'])
parser.add_argument('-debug', '--debug', help='Use debug mode?', type='bool',
                    default=False)


def fix_title(title: str):
    """
    Movies sometimes are
    "NAME, The"  ==>  "The NAME"

    Change & ==> and
    :param title:
    :return:
    """
    if title.endswith(", The"):
        title = "The " + title[:-len(", The")]
    title = title.replace("&", "and")
    return title


def preprocess_text(title: str, plot: str, SEP_TOKEN: str):
    """
    Perform preprocessing

    :param title:
    :param plot:
    :param SEP_TOKEN:
    :return:
    """
    title_tokens = " ".join(tokenizer(fix_title(title)))

    # Remove plot withs crediting the authors
    # EG ".... Who will win?::Kris Hopson"
    match = regex.search(r"::\w+\s{0,1}\w+$", plot)

    # If not then find some with ending with an email
    # EG "::<jhailey@hotmail.com >"
    if not match:
        match = regex.search(r"::<\w+@\w+\.\w{,3}\s?>", plot)

    if match:
        plot = plot[:match.start()]

    plot_tokens = " ".join(tokenizer(plot))
    return title_tokens + SEP_TOKEN + plot_tokens


def test_preprocess():
    """Check preprocessing results"""
    s = "Who will win?::Kris Hopson"
    assert preprocess_text("", s, "") == "Who will win ?"

    s = "an asset?::<jhailey@hotmail.com >"
    assert preprocess_text("", s, "") == "an asset ?"


def replace_movie(s, row):
    mentions = row['movieMentions']
    questions = row['initiatorQuestions']
    match = regex.search(r"(@\d+)", s)
    ids = []

    while match:
        start, end = match.span()
        movie_id = match.group(0)[1:]
        # ConvMovie: ID
        ids.append(movie_id)
        if movie_id not in mentions:
            print("Could not find movie in mentions...", movie_id)
            break
        # Remove Year from title
        movie_name = regex.sub(r"\(\d+\)$", "", mentions[movie_id]).strip()
        # Seeker mentioned
        s = f"{s[:start]} {movie_name} {s[end:]}"
        match = regex.search(r"(@\d+)", s)
    # Remove double whitespace
    s = regex.sub(r"\s{2,}", " ", s)
    return s, ids


def construct_episodes_v2(save_filename: str, movies_list: List[Movie],
                          encoder: TextEncoder, opt):
    """

    movies_list -> List[Movies], Attributes: movie_id, ml_id, matrix_id, title, plot

    :param save_filename:
    :param movies_list:
    :param encoder:
    :return:
    """
    HISTORY_LEN = opt.history_length
    if opt.test:
        print("Using test dataset....")
    filename = "data/test_data.jsonl" if opt.test else "data/train_data.jsonl"
    with open(filename, 'r') as f:
        data = [json.loads(line) for line in f]

    if opt.max_examples != -1:
        print(f"Truncating to {opt.max_examples} episodes")
        np.random.shuffle(data)
    # if BERT use [SEP] token else .
    SEP_TOKEN = " [SEP] " if opt.encoder == 'bert' else " . "
    data = pd.DataFrame.from_dict(data)
    print("Encoding movie plots")
    # Encode Movie Title/Plot
    for movie in tqdm(movies_list):
        txt = preprocess_text(movie.title, movie.plot, SEP_TOKEN)
        movie.text = txt
        movie.vector = encoder.encode(txt)[0]

    # Movie Mapping
    _movieid_to_list = {str(movie.movie_id): movie for movie in movies_list}

    # Preprocess our examples
    episodes = []
    print("Starting preprocessing....")

    for _, row in tqdm(data.iterrows(), total=opt.max_examples):
        example = []
        convId = row.conversationId
        # Seeker ID
        seeker_id = row.initiatorWorkerId
        # Recommender ID
        rec_id = row.respondentWorkerId
        prev_id = None
        # Questions = {'203371': {'suggested': 1, 'seen': 0, 'liked': 1}}
        questions = row['initiatorQuestions']
        seen = set()
        for i, msg in enumerate(row.messages):
            is_seeker = msg['senderWorkerId'] == seeker_id

            # Replace movie ids with names, return ids
            text, ids = replace_movie(msg['text'], row)

            movie_matches = []
            for _id in ids:
                # If we have the movie and they like it or did not say
                if _id in _movieid_to_list:
                    # If seeker and liked the movie, sometimes missing in questions
                    # We only ignore if its a strong preference eg they do not like it
                    if len(questions) and is_seeker \
                            and _id in questions \
                            and questions[_id]['liked'] != 0:
                        continue

                    # We do not have this movie in the item matrix
                    if _movieid_to_list[_id].matrix_id == -1:
                        continue
                    ml_id = _movieid_to_list[_id].ml_id
                    if ml_id not in seen:
                        movie_matches.append(ml_id)
                        seen.add(ml_id)

            # Perform tokenization then rejoin since the model performs
            # whitespace tokenization
            text = " ".join(tokenizer(text))

            # add to previous
            if msg['senderWorkerId'] == prev_id:
                example[-1]['text'] += " " + text
                example[-1]['movie_id'] += ids
                example[-1]['ml_id'] += movie_matches
            else:
                # New Speaker
                # Text, Movie IDs, MovieLens IDS
                example.append(
                    dict(seeker=is_seeker, text=text, movie_id=ids,
                         ml_id=movie_matches, convId=convId))
            prev_id = msg['senderWorkerId']

        # Skip empty
        if sum([len(ex['ml_id']) for ex in example]) == 0:
            continue

        # Truncate the end if no other recommendations are performed
        while len(example[-1]['ml_id']) == 0:
            example.pop()

        if len(example) == 0:
            raise Exception(f"Example has 0 entries... ConvId: {convId}")

        # Keep a history length of dialog to 2
        history = deque(maxlen=HISTORY_LEN)
        # Encode each text
        for i, ex in enumerate(example):
            history.append(ex['text'])
            # Query vector is seen after we perform evaluation important!
            example[i]['query_vec'] = encoder.encode(SEP_TOKEN.join(history))[0]

        if len(example):
            episodes.append(example)

        if len(episodes) == opt.max_examples:
            break

    print(f"Total Episodes: {len(episodes)}")
    print("Encoding movies")
    movies_list = [movie.to_dict() for movie in movies_list]
    print(f"DONE!\nSaving to file: {save_filename}")
    pickle.dump({'episodes': episodes,
                 'movies': movies_list,
                 }, open(save_filename, 'wb'))


def print_statistics(episodes, movies_list):
    """
    Compute some statistics for data

    :param episodes: List
    :param movies_list: List of movies
    """
    avg_episode_len = np.mean([len(ex) for ex in episodes])
    print("{:<50} {:.4f}".format("Avg Episode Length", avg_episode_len))

    valid_movies = [sum([len(ex['ml_id']) for ex in episode]) for episode in episodes]
    print("\nValid Movies")
    print("{:<50} {:.4f}".format("Avg Movies/Episode", np.mean(valid_movies)))
    print("{:<50} {:.4f}".format("Min Movies/Episode", np.min(valid_movies)))
    print("{:<50} {:.4f}".format("Max Movies/Episode", np.max(valid_movies)))

    n_tokens = [len(movie.plot_tokens) + len(movie.title_tokens) for movie in movies_list]
    print("\nMovie Summary Statistics")
    print("{:<50} {:.4f}".format("Avg Tokens", np.mean(n_tokens)))
    print("{:<50} {:.4f}".format("Min Tokens", np.min(n_tokens)))
    print("{:<50} {:.4f}".format("Max Tokens", np.max(n_tokens)))


if __name__ == '__main__':
    opt = parser.parse_args()
    print(opt)
    np.random.seed(opt.seed)
    print(f"Loading {opt.input}")
    movies_list = pickle.load(open(opt.input, 'rb'))
    movies_list = [Movie.from_dict(m) for m in movies_list]
    if opt.debug:
        test_preprocess()
        SEP_TOKEN = " [SEP] " if opt.encoder == 'bert' else " . "
        print()

        # Encode Movie Title/Plot
        for movie in np.random.choice(movies_list, size=500):
            print(preprocess_text(movie.title, movie.plot, SEP_TOKEN))
            print("="*80)
        print()
    else:
        # Initialize Text Encoder
        print("Loading pretrained models....")
        encoder = TextEncoder(opt.gpu, opt.encoder)

        print(f"Preprocessing episodes to {opt.output}")
        construct_episodes_v2(opt.output, movies_list, encoder, opt)
