"""
Pretrain a weighted content based item latent factor model

wc=10
================================================================================
Train Recall@ 10:     0.00003              Test Recall@ 10:     0.00000
Train Recall@ 25:     0.00014              Test Recall@ 25:     0.00011
Train Recall@ 50:     0.00042              Test Recall@ 50:     0.00038
--------------------------------------------------------------------------------
Train Prec@ 10:       0.00024              Test Prec@ 10:       0.00002
Train Prec@ 25:       0.00066              Test Prec@ 25:       0.00007
Train Prec@ 50:       0.00086              Test Prec@ 50:       0.00010
================================================================================

wc=20
================================================================================
Train Recall@ 10:     0.00053              Test Recall@ 10:     0.00055
Train Recall@ 25:     0.00078              Test Recall@ 25:     0.00077
Train Recall@ 50:     0.00106              Test Recall@ 50:     0.00109
--------------------------------------------------------------------------------
Train Prec@ 10:       0.00704              Test Prec@ 10:       0.00072
Train Prec@ 25:       0.00400              Test Prec@ 25:       0.00040
Train Prec@ 50:       0.00250              Test Prec@ 50:       0.00025
================================================================================

Freezing User embeddings did not seem to help...
"""
import torch
import torch.nn as nn
import sys, shutil, json
import rutil
import argparse
# from util.helper import setup_exp
import os
import numpy as np
from tqdm import tqdm
from util.data import WeightedContentDataset
from util.helper import Timer
from rutil.metric.ir import precision_recall_score
from torch.utils.data import DataLoader
import rutil.util
parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
parser.add_argument('-g', '--gpu', help='set gpu device number 0-3', type=str,
                    default="0")
parser.add_argument('-d', '--dataset', help='directory to train/test npz file',
                    type=str, required=True)
parser.add_argument('-nt', '--num_threads', help='Number of threads for data loader',
                    type=int, default=8)
parser.add_argument('-mf', '--model_file', help='path to model directory',
                    type=str,  default=None)
parser.add_argument('-p', '--models', help='path to pretrained model',
                    type=str,  default=None)

parser.add_argument('-i', '--iters', help='Max iters', type=int, default=15)
parser.add_argument('-bs', '--batch_size', help='Batch Size', type=int, default=128)
parser.add_argument('-l2', '--l2', help='l2 Regularization', type=float, default=1e-6)
parser.add_argument('-e', '--embed_size', help='Embedding Size', type=int, default=8)
parser.add_argument('-n', '--neg_count', help='Negative Samples Count', type=int, default=4)
parser.add_argument('-wc', '--weight_count', help='Number of weighted latent '
                                                  'factors to use per an example', type=int, default=10)
parser.add_argument('-top', '--top_sim', help='Total number of top similar items to select from',
                    type=int, default=300)

parser.add_argument('-m', '--model', help='path to model directory',
                    type=str,  default='gmf', choices=['gmf', 'mf'])



class WeightedContentPairwiseGMF(nn.Module):

    def __init__(self, config):
        super().__init__()
        self.config = config
        self.user_memory = nn.Embedding(self.config.user_count,
                                        self.config.embed_size)
        self.item_memory = nn.Embedding(self.config.item_count,
                                        self.config.embed_size)
        # Final projection vector
        self.v = nn.Linear(self.config.embed_size, 1, bias=False)
        self.act = nn.ReLU()
        nn.init.normal_(self.user_memory.weight, std=0.01)
        nn.init.normal_(self.item_memory.weight, std=0.01)
        nn.init.xavier_normal_(self.v.weight)
        self.new_user = nn.Parameter(torch.Tensor(self.config.embed_size))
        nn.init.normal_(self.new_user.data, std=0.01)
        self._user_mean = None
        self._user_std = None

    def forward(self, user_id, item_id, item_sim, neg_item_id=None, neg_sim=None):
        """

        :param user_id: [batch size]
        :param item_id: [batch size, n weighted items]
        :param item_sim: [batch size, n weighted items]
        :param neg_item_id: [batch size, n weighted items]
        :param neg_sim: [batch size, n weighted items]
        :return:
        """
        user = self.user_memory(user_id)
        # [batch, weighted_count, embed size]
        item = self.item_memory(item_id)
        # [batch, 1, embed_size]
        query = item[:, -1].view(item.shape[0], 1, item.shape[-1])

        # [batch, item_weighted count]
        sim = (query * item).sum(-1)
        attn = nn.functional.softmax(sim, -1)
        # [batch, weighted count, 1]
        attn = attn.unsqueeze(-1)

        # [batch, weighted count, embed] =>
        item = (item * attn).sum(1)

        # # [batch, weighted count, 1]
        # item_sim = item_sim.unsqueeze(-1)
        #
        # # [batch, embed size]
        # item = (item_sim * item).sum(1)

        score = self.v(self.act(user * item)).squeeze()
        if neg_item_id is not None:
            neg_item = self.item_memory(neg_item_id)
            # [batch, 1, embed_size]
            neg_query = neg_item[:, -1].view(neg_item.shape[0], 1, neg_item.shape[-1])

            # [batch, item_weighted count]
            neg_sim = (neg_query * neg_item).sum(-1)
            neg_attn = nn.functional.softmax(neg_sim, -1)
            # [batch, weighted count, 1]
            neg_attn = neg_attn.unsqueeze(-1)

            # [batch, weighted count, embed] =>
            neg_item = (neg_item * neg_attn).sum(1)

            # # [batch, weighted count, 1]
            # neg_sim = neg_sim.unsqueeze(-1)
            # # [batch, weighted_count, embed size]
            # neg_item = self.item_memory(neg_item_id)
            # neg_item = (neg_sim * neg_item).sum(1)
            neg_score = self.v(self.act(user * neg_item)).squeeze()
            return score, neg_score
        return score

    def get_weighted_item_embed(self, item_indices, item_scores):
        """

        :param item_indices: [bs, n_weighted items]
        :param item_scores: [bs, n weighted items]
        :return:
        """
        # This below is a self attention type
        # item = self.item_memory(item_indices)
        # # [batch, 1, embed_size]
        # query = item[:, -1].view(item.shape[0], 1, item.shape[-1])
        #
        # # [batch, item_weighted count]
        # sim = (query * item).sum(-1)
        # attn = nn.functional.softmax(sim, -1)
        # # [batch, weighted count, 1]
        # attn = attn.unsqueeze(-1)
        #
        # # [batch, weighted count, embed] => [batch, embed]
        # return (item * attn).sum(1)
        item_scores = item_scores.unsqueeze(-1)
        # [bs, n, embed]
        items = self.item_memory(item_indices)

        # [bs, n embed]
        return (item_scores * items).sum(1)

    def recommend(self, user_id, item_embeddings=None):
        """
        Given a Tensor of item_ids return the recommendation scores for all
        users for the given item_id

        :param user_id: [batch size]
        :return: [batch size, n_users]
        """
        # [n users, 1, embed]
        expand_user = self.user_memory(user_id).unsqueeze(1)
        if item_embeddings is None:
            expand_item = self.item_memory.weight.unsqueeze(0)
        else:
            # [1, n items,  embed] ==> [n items, n users, embed]
            if item_embeddings.dim() == 2:
                item_embeddings = item_embeddings.unsqueeze(0)
            expand_item = item_embeddings

        elementwise = self.act(expand_item * expand_user)
        shape = elementwise.shape
        return self.v(elementwise.view(-1, shape[-1])).view(shape[0], shape[1])

    def new_user_reset(self, mean: torch.FloatTensor, std: torch.FloatTensor):
        """
        Reset the user latent factor

        :param mean:
        :param std:
        :return:
        """
        if not mean.shape == std.shape == self.new_user.shape:
            print(f"Invalid mean/std shape should be {self.new_user.shape}")
            raise Exception(f"Invalid mean/std shape should be {self.new_user.shape}")
        self._user_mean = mean
        self._user_std = std
        # Init to normal with same mean/std
        self.new_user.data = torch.normal(mean, std).to(next(self.parameters()).device)

    def new_user_score(self, item_lf: torch.FloatTensor, method):
        """
        Given the new weighted item latent factor compute this with the new
        user latent factor.

        :param item_lf: item latent factor, [batch, embed size] or [embed size]
        :return: Recommendation score
        """
        # [1, embed]
        user_term = self.new_user.unsqueeze(0)

        if item_lf.dim() == 1:
            item_lf = item_lf.unsqueeze(0)

        if method == 'inner':
            user_term = user_term
        elif method == 'offset':
            user_term = (self._user_mean.data.view(1, -1) + user_term)
        else:
            raise Exception("Unknown method: %s" % method)
        # [bs, embed] => [bs]
        return self.v(self.act(user_term * item_lf)).squeeze()

    def new_user_recommend(self, method):
        """
        Perform recommendation over all the items

        :return:
        """
        user_term = self.new_user.unsqueeze(0)
        if method == 'inner':
            user_term = user_term
        elif method == 'offset':
            user_term = (self._user_mean.data.view(1, -1) + user_term)
        else:
            raise Exception("Unknown method: %s" % method)

        return self.v(self.act(self.item_memory.weight * user_term)).squeeze()


if __name__ == '__main__':
    opt = parser.parse_args()
    print("Loading dataset....")
    dataset = WeightedContentDataset(opt.dataset, "data/v2/movie_matrix.npy",
                                     opt.neg_count, opt.top_sim, opt.weight_count,
                                     apply_softmax=True)
    # Dataset Specific
    opt.item_count = dataset.item_count
    opt.user_count = dataset.user_count
    rutil.util.setup_exp(opt)
    DEVICE = 'cuda' if opt.gpu != -1 else 'cpu'
    print(opt)
    model = WeightedContentPairwiseGMF(opt).to(DEVICE)

    if opt.pretrain:
        print("Loading pretrained model from", opt.pretrain)
        states = torch.load(open(opt.pretrain, 'rb'), map_location='cpu')
        model.load_state_dict(states['model'], strict=False)
        # model.user_memory.weight.requires_grad = False

    optimizer = torch.optim.Adam([p for p in model.parameters() if p.requires_grad],
                                 weight_decay=opt.l2)
    # optimizer = torch.optim.RMSprop([p for p in model.parameters() if p.requires_grad],
    #                                 lr=0.01, weight_decay=opt.l2, momentum=0.9)
    epoch = 0

    if opt.model_file:
        save_model_filename = os.path.join(opt.model_file, 'model.pth')
        if os.path.exists(save_model_filename):
            print(f"Loading Existing Model From {save_model_filename}")
            states = torch.load(open(save_model_filename, 'rb'), map_location='cpu')
            model.load_state_dict(states['model'], strict=False)
            optimizer.load_state_dict(states['opt'])
            epoch = states.get('epoch', 0)
            print(f"Resuming from epoch {epoch}")

    dataloader_kwargs = dict(batch_size=opt.batch_size, shuffle=True,
                             num_workers=opt.num_threads, pin_memory=True)
    dataloader = DataLoader(dataset, **dataloader_kwargs)

    EVAL_AT = [10, 25, 50]
    test_batch_size = 32

    total_time = Timer()
    # Train Loop
    while epoch < opt.iters:
        # Apply linear start for n-epochs
        # if epoch == 2:
        #     print("[Switching to Softmax from Linear Start]")
        #     dataset.apply_softmax = True
        #     dataloader = DataLoader(dataset, **dataloader_kwargs)
        ############################################
        # Training
        ############################################
        epoch += 1
        model.train()
        progress = tqdm(dataloader, total=len(dataset),
                        dynamic_ncols=True, leave=False)
        loss = []
        epoch_time = Timer()
        for example in progress:
            optimizer.zero_grad()
            example = [ex.cuda(non_blocking=True) for ex in example]
            user_idx, item_idx, item_sim, neg_idx, neg_sim = example
            pos = model(user_idx, item_idx, item_sim)
            neg = model(user_idx, neg_idx, neg_sim)
            batch_loss = -torch.log(torch.sigmoid(pos-neg) + 1e-8).mean()
            batch_loss.backward()
            optimizer.step()
            loss.append(batch_loss.data.item())
            progress.set_description(u"[{}] Loss: {:,.4f} » » » » ".format(epoch, batch_loss.item()))
        print("Epoch {}: Avg Loss/Batch {:<20,.6f}".format(epoch, np.mean(loss)))
        if opt.model_file:
            torch.save({'opt': optimizer.state_dict(),
                        'model': model.state_dict(),
                        'params': opt, 'epoch': epoch},
                       open(os.path.join(opt.model_file, 'model.pth'), 'wb'))

        ############################################
        # Evaluation -------------------------------
        ############################################
        model.eval()
        batch_scores = []
        index = np.arange(dataset.user_count, dtype=np.int64)
        batch_count = int(np.floor(dataset.user_count/test_batch_size))
        batch_count = min(batch_count, test_batch_size*20)
        print(f"\n\nEvaluating on {batch_count*test_batch_size} users!")
        train_prec, train_recall, test_prec, test_recall = [], [], [], []
        user_offset = 0
        # mask = np.eye(dataset.max_item_neighbors).astype(np.float32)
        # mask[mask == 1] = 1e-20
        # mask[mask == 0] = 1
        # Zero out diag
        # sim = sim * mask[:len(user_observations), :len(user_observations)]
        # item_index = np.argsort(sim)[:, :opt.weight_count]
        # item_scores = np.take(sim, item_index)
        user_eval_count = min(20000, dataset.user_count)
        with torch.no_grad():
            for i in tqdm(range(batch_count), desc="Evaluation", leave=False):
                lo = i * test_batch_size
                hi = lo + test_batch_size
                idx = index[lo:hi]
                # item_embeddings = []
                # for user in idx:
                #     user_observations = dataset.user_items_list[user]
                #     # Similarity of each item wrt to other observations
                #     # select the mixture of latent factors to use from observed
                #     # [N observed, number of items]
                #     sim = dataset.sim[:, user_observations]
                #     item_index = np.argsort(-sim, axis=0)[:, :opt.weight_count]
                #     item_scores = nn.functional.softmax(torch.from_numpy(np.take(sim, item_index)).to(DEVICE), -1)
                #     item_index = torch.from_numpy(item_index).to(DEVICE)
                #     item_latent = model.get_weighted_item_embed(item_index, item_scores)
                #     item_embeddings.append(item_latent)
                #
                idx = torch.from_numpy(idx).to(DEVICE)
                # item_embeddings = torch.stack(item_embeddings)
                # s = model.recommend(idx, item_embeddings).data.cpu().numpy()
                s = model.recommend(idx).data.cpu().numpy()
                if len(s.shape) == 1:
                    s = s.reshape(1, -1)
                batch_scores.append(s)
                # Evaluate every 10, else we can run out of memory
                if len(batch_scores) > 20 or i == (batch_count-1):
                    scores = np.concatenate(batch_scores)
                    batch_scores = []
                    batch_train_prec, batch_train_recall = precision_recall_score(
                        scores, dataset.train_relevance, EVAL_AT, return_all=True, offset=user_offset)
                    train_prec.append(batch_train_prec)
                    train_recall.append(batch_train_recall)

                    batch_test_prec, batch_test_recall = precision_recall_score(
                        scores, dataset.test_relevance, EVAL_AT, return_all=True,
                        offset=user_offset)
                    test_prec.append(batch_test_prec)
                    test_recall.append(batch_test_recall)
                    user_offset += scores.shape[0]

                """
                # For each item
                item_latent = []
                for i, sim in enumerate(dataset.sim):
                    sim = sim[user_observations]
                    item_index = np.argsort(-sim)[:opt.weight_count]
                    item_scores = nn.functional.softmax(torch.from_numpy(sim[item_index]).to(DEVICE), -1)
                    item_index = torch.from_numpy(item_index).to(DEVICE).view(1, -1)
                    item_latent.append(model.get_weighted_item_embed(item_index, item_scores))
                item_latent = torch.cat(item_latent, 0)
                
                s = model.recommend(torch.LongTensor([user]).to(DEVICE), item_latent)

                if len(s.shape) == 1:
                    s = s.reshape(1, -1)
                batch_scores.append(s)
                # Evaluate every 10, else we can run out of memory
                if len(batch_scores) > 10000 or user == (user_eval_count - 1):
                    scores = np.concatenate(batch_scores)
                    batch_scores = []
                    batch_train_prec, batch_train_recall = precision_recall_score(
                            scores, dataset.train_relevance, EVAL_AT, return_all=True, offset=user_offset)
                    train_prec.append(batch_train_prec)
                    train_recall.append(batch_train_recall)
                    batch_test_prec, batch_test_recall = precision_recall_score(
                            scores, dataset.test_relevance, EVAL_AT, return_all=True,
                            offset=user_offset)
                    test_prec.append(batch_test_prec)
                    test_recall.append(batch_test_recall)
                    user_offset += scores.shape[0]
                """
        # with torch.no_grad():
        #     lf_index = dataset.pos_index[:, :opt.weight_count]
        #     item_scores = np.empty(lf_index.shape, dtype=np.float32)
        #     np.take(dataset.sim, lf_index, out=item_scores)  # Memory error otherwise
        #     item_scores = torch.from_numpy(item_scores).to(DEVICE)
        #     # Normalize
        #     item_scores = torch.nn.functional.softmax(item_scores, -1)
        #
        #     item_embeddings = model.get_weighted_item_embed(
        #         torch.from_numpy(lf_index).long().to(DEVICE), item_scores)
        #
        #     for i in tqdm(range(batch_count), desc="Evaluation", leave=False):
        #         lo = i * test_batch_size
        #         hi = lo + test_batch_size
        #         idx = torch.from_numpy(index[lo:hi])
        #         idx = idx.to(DEVICE)
        #         s = model.recommend(idx, item_embeddings).data.cpu().numpy()
        #         if len(s.shape) == 1:
        #             s = s.reshape(1, -1)
        #         batch_scores.append(s)
        #         # Evaluate every 10, else we can run out of memory
        #         if len(batch_scores) > 20 or i == (batch_count-1):
        #             scores = np.concatenate(batch_scores)
        #             batch_scores = []
        #             batch_train_prec, batch_train_recall = precision_recall_score(
        #                 scores, dataset.train_relevance, EVAL_AT, return_all=True, offset=user_offset)
        #             train_prec.append(batch_train_prec)
        #             train_recall.append(batch_train_recall)
        #
        #             batch_test_prec, batch_test_recall = precision_recall_score(
        #                 scores, dataset.test_relevance, EVAL_AT, return_all=True,
        #                 offset=user_offset)
        #             test_prec.append(batch_test_prec)
        #             test_recall.append(batch_test_recall)
        #             user_offset += scores.shape[0]

        s = "\n\n" + ("=" * 80) + "\n"
        p = ("-" * 80) + "\n"
        train_prec = np.concatenate(train_prec, 1).mean(1)
        train_recall = np.concatenate(train_recall, 1).mean(1)
        test_prec = np.concatenate(test_prec, 1).mean(1)
        test_recall = np.concatenate(test_recall, 1).mean(1)
        summary = {}
        for _idx in range(len(EVAL_AT)):
            K = EVAL_AT[_idx]
            summary.update({
                f"train_recall{K}": float(train_recall[_idx]),
                f"recall{K}": float(test_recall[_idx]),
                f"train_prec{K}": float(train_prec[_idx]),
                f"prec{K}": float(test_prec[_idx]),
            })
            s += "Train Recall@{k:>3}:     {train:<20} Test Recall@{k:>3}:     {test:<20}\n".format(
                    train="{:.5f}".format(train_recall[_idx]),
                    test="{:.5f}".format(test_recall[_idx]),
                    k=K)
            p += "Train Prec@{k:>3}:       {train:<20} Test Prec@{k:>3}:       {test:<20}\n".format(
                    train="{:.5f}".format(train_prec[_idx]),
                    test="{:.5f}".format(test_prec[_idx]),
                    k=K)

        if opt.model_file:
            summary['epoch'] = epoch
            summary['loss'] = float(np.mean(loss))
            with open(os.path.join(opt.model_file, 'results.json'), 'a') as f:
                f.write(json.dumps(summary, sort_keys=True))
                f.write("\n")
        print(s + p + ("=" * 80))
        print("Epoch Took: %s" % epoch_time)
        print("Total Time Elapsed: %s" % total_time)
        print()







