#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@author:   Travis A. Ebesu
@created:  2017-05-08
@summary:  Evaluation for LOOCV
"""
from collections import namedtuple

import numpy as np
import tensorflow as tf
from tqdm import tqdm

# Placeholder to pass between model and evaluation methods
EvalHandle = namedtuple("EvalHandle", ['user', 'item', 'neighborhood',
                                       'neighborhood_len', 'eval_op'])


def get_ranking_scores(sess: tf.Session,
                       test_data: dict,
                       eval_handle: EvalHandle,
                       neighborhood: dict,
                       max_neighbors: int,
                       return_report: bool=False):
    """
    Get the ranking scores from the model given the test data

    test_data = dict({user_id: [positive, np.array[negatives]]})

    :param sess: Active TensorFlow Session
    :param test_data: Testing data
    :param eval_handle: Handle from model
    :param neighborhood: Contains the neighborhood information mapping an item
                         to each user
    :param max_neighbors: the max size of the neighborhood
    :param return_report: If true, returns a string of the ranking scores with
                          format user_id \t score_1:item_id_1 score_2:item_id_2
    :return:
    """
    out = ''
    scores = []
    progress = tqdm(test_data.items(), total=len(test_data),
                    leave=False, desc=u'Evaluate || ')
    for user, (pos, neg) in progress:
        item_indices = list(neg) + [pos]

        feed = {
            eval_handle.user: [user] * (len(neg) + 1),
            eval_handle.item: item_indices,
        }

        if neighborhood is not None:
            neighborhoods = np.zeros((len(neg) + 1, max_neighbors),
                                     dtype=np.int32)
            neighborhood_length = np.ones(len(neg) + 1, dtype=np.int32)

            for _idx, item in enumerate(item_indices):
                _len = min(len(neighborhood.get(item, [])), max_neighbors)
                if _len > 0:
                    neighborhoods[_idx, :_len] = neighborhood[item][:_len]
                    neighborhood_length[_idx] = _len
                else:
                    neighborhoods[_idx, :1] = user
            feed.update({
                eval_handle.neighborhood: neighborhoods,
                eval_handle.neighborhood_len: neighborhood_length
            })

        score = sess.run(eval_handle.eval_op, feed)
        scores.append(score.ravel())
        if return_report:
            s = ' '.join(["{}:{}".format(n, s) for s, n in zip(score.ravel().tolist(), item_indices)])
            out += "{}\t{}\n".format(user, s)
    if return_report:
        return scores, out
    return scores


def evaluate_model(sess: tf.Session,
                   test_data: dict,
                   eval_handle: EvalHandle,
                   neighborhood: dict,
                   max_neighbors: int,
                   eval_at: list=[1, 5, 10]):
    """
    Evaluate HitRate and NDCG, returns them and also tf.logging.info results

    :param sess: Active TensorFlow Session
    :param test_data: Testing data
    :param eval_handle: Handle from model
    :param neighborhood: Contains the neighborhood information mapping an item
                         to each user
    :param max_neighbors: the max size of the neighborhood
    :param eval_at: iterable of cut offs to evaluate the model at
    :return:
    """
    scores = get_ranking_scores(sess, test_data, eval_handle, neighborhood,
                                max_neighbors)
    hrs = []
    ndcgs = []
    s = '\n'
    for k in eval_at:
        hr, ndcg = get_hr_ndcg(scores, len(scores[0]) - 1, k)
        s += "{:<14} {:<14.6f}{:<14} {:.6f}\n".format('HR@%s' % k, hr, 'NDCG@%s' % k, ndcg)
        hrs.append(hr)
        ndcgs.append(ndcg)
    tf.logging.info(s + '\n')

    return hrs, ndcgs


def get_hr_ndcg(scores: np.ndarray, index: int, top_n: int=10):
    """
    Get the HitRate and NDCG @TopN for Leave-One-Out Cross Validation

    if the last element is the correct one, then
    index = len(scores[0])-1

    :param scores: Ranking scores for each item
    :param index: corresponding index with the positive/correct item
    :param top_n: cut off for topn evaluation
    :return: hit rate, ndcg
    """
    ndcg = 0.0
    hr = 0.0
    assert len(scores[0]) > index >= 0

    for score in scores:
        # Get the top n indices
        arg_index = np.argsort(-score)[:top_n]
        if index in arg_index:
            # Get the position
            ndcg += np.log(2.0) / np.log(arg_index.tolist().index(index) + 2.0)
            # Increment
            hr += 1.0

    return hr / len(scores), ndcg / len(scores)


