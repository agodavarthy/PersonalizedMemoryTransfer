import util.helper
from util.latent_factor import MovieSelector
from util.simulator import MovieConversationSimulator
import torch
import util.models.mf
import json
import datetime as dt
from itertools import product
import copy
import util.results
from sklearn.utils import shuffle

parser = util.helper.get_parser()


if __name__ == '__main__':
    opt = parser.parse_args()
    keeper = util.results.ExperimentTracker("results/conv.csv")
    simulator = MovieConversationSimulator(opt.data)
    selector = MovieSelector(simulator.movies_list, 'cpu')

    states = torch.load(opt.model_file, 'cpu')
    if opt.model == 'gmf':
        model = util.gmf.PytorchPairwiseGMF(states['params'])
    elif opt.model == 'mf':
        model = util.models.mf.MatrixFactorization(states['params'])
    model.load_state_dict(states['model'])

    for p in model.item_memory.parameters():
        p.requires_grad = False

    for p in model.user_memory.parameters():
        p.requires_grad = False

    if hasattr(model, 'v'):
        for p in model.v.parameters():
            p.requires_grad = False

    # Shuffle so we can run in parallel w minimal overlap
    all_params = shuffle(list(product(
            [{'weighted_count': x} for x in [
                300, 25, 50, 100
                # 5, 10, 20, 500, 300, 30, 15,
                #  25, 30, 40, 50, 75, 80, 100, 250
            ]],
            [{'neg_count': x} for x in
             [
                 5, 10, 30# 50, 60, 70, 25, 15,
             ]],
            [{'update': x} for x in ['seeker']],
            # [{'sampling': x} for x in ['random', 'hard']],
            # [{'lr': x} for x in [0.1, 0.01]],
    )))  # + [[{5: 5}]]

    print(f"Running Experiments: {len(all_params):,}")
    for subparam in all_params:
        new_params = copy.deepcopy(opt)
        for d in subparam:
            # param.update(d)
            for k, v in d.items():
                # new_params[k] = v
                setattr(new_params, k, v)
        print(new_params)
        print()
        skip = not keeper.should_run(new_params.__dict__)
        if skip:
            print("Already Completed Skipping...")
            continue

        print("Running:", new_params)
        results = util.results.run(new_params, simulator, selector, model)
        print(json.dumps(results, indent=2))
        print()

        summary = simulator.metrics().copy()
        summary.update(new_params.__dict__)
        summary['time'] = str(dt.datetime.now())
        summary['params'] = states['params'].__dict__
        # Writer
        keeper.report(summary)
