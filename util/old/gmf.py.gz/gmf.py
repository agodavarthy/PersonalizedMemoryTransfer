#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@author:   Travis A. Ebesu
@created:  2017-05-08
@summary:  BPR Pairwise Generalized Matrix Factorization

GMF see
He, X., Liao, L., Zhang, H., Nie, L., Hu, X., & Chua, T. S. (2017, April).
Neural collaborative filtering.

This is basically CMN without Attention/Memory Network and additional projection
matrices.
"""
import sonnet as snt
import tensorflow as tf

from util.old.helper import GraphKeys, add_to_collection, caffe_init
from util.old.layers import DenseLayer, LossLayer, OptimizerLayer, ModelBase
import torch
import torch.nn as nn
import math


class PairwiseGMF(ModelBase):

    def __init__(self, config):
        """

        :param config:
        """
        super(PairwiseGMF, self).__init__(config)
        self.config = config
        self._activation_fn = tf.nn.relu
        self._embedding_initializers = {
            'embeddings': tf.truncated_normal_initializer(stddev=0.01),
        }

        self._embedding_regularizers = {}

        self._initializers = {
            "w": tf.contrib.layers.xavier_initializer(),
        }

        self._regularizers = {
            'w': tf.contrib.layers.l2_regularizer(config.l2)
        }
        self._construct_placeholders()
        self._construct_weights()
        self._build_model()
        tf.summary.scalar('Model/Loss', tf.get_collection(GraphKeys.LOSSES)[0])
        self.summary = tf.summary.merge_all()

    def _build_model(self):
        """
        Construct the model
        """
        # Ranking op
        self.score = tf.squeeze(self.v(tf.nn.relu(self._cur_user * self._cur_item)))

        # [1, n users, embed]
        expand_user = tf.expand_dims(self.user_memory.embeddings, 0)

        # [bs, 1, embed] ==> [bs, n users, embed]
        expand_item = tf.expand_dims(self._cur_item, 1)
        elementwise = tf.nn.relu(expand_user * expand_item)

        self.recommend = tf.squeeze(snt.BatchApply(self.v)(elementwise))

        # Negative Sample
        negative_output = tf.squeeze(self.v(tf.nn.relu(
                self._cur_user * self._cur_item_negative)))
        # BPR Loss
        self.loss = LossLayer()(self.score, negative_output)
        self._optimizer = OptimizerLayer(self.config.optimizer, clip=5.0,
                                         params={})
        self.train = self._optimizer(self.loss)

        tf.add_to_collection(GraphKeys.PREDICTION, self.score)

    def _construct_placeholders(self):
        """Create placeholders for our model"""
        # UserID input
        self.input_users = tf.placeholder(tf.int32, [None], 'UserID')
        # ItemID input
        self.input_items = tf.placeholder(tf.int32, [None], 'ItemID')
        # Pairwise Negative Item ID
        self.input_items_negative = tf.placeholder(tf.int32, [None], 'NegativeItemID')

        # Add our placeholders
        add_to_collection(GraphKeys.PLACEHOLDER, [self.input_users,
                                                  self.input_items,
                                                  self.input_items_negative])

    def _construct_weights(self):
        """
        This functions constructs the user/item memories (latent factors)

        Also add the embedding lookups for convenience call after placeholders
        are constructed
        """
        self.user_memory = snt.Embed(self.config.user_count, self.config.embed_size,
                                     initializers=self._embedding_initializers,
                                     name='MemoryEmbed')

        self.item_memory = snt.Embed(self.config.item_count,
                                     self.config.embed_size,
                                     initializers=self._embedding_initializers,
                                     name="ItemMemory")
        # Final projection vector
        self.v = DenseLayer(1, False, None,
                            initializers=self._initializers,
                            regularizers=self._regularizers,
                            name='OutputVector')

        # [batch, embedding size]
        self._cur_user = self.user_memory(self.input_users)

        # Item memories a query
        self._cur_item = self.item_memory(self.input_items)
        self._cur_item_negative = self.item_memory(self.input_items_negative)
